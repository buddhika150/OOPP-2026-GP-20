package bmi;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BMIGui extends JFrame {


    private JLabel headerLabel = new JLabel("BMI CALCULATOR", SwingConstants.CENTER);


    private JRadioButton metricRadio = new JRadioButton("Metric Units (kg, cm/m)", true);
    private JRadioButton imperialRadio = new JRadioButton("Imperial Units (lbs, in)");
    private JLabel heightLabel = new JLabel("Height:");
    private JLabel weightLabel = new JLabel("Weight:");

    private JLabel heightHint = new JLabel("");
    private JLabel weightHint = new JLabel("");

    private JTextField heightField = new JTextField(12);
    private JTextField weightField = new JTextField(12);
    private JButton calculateButton = new JButton("CALCULATE BMI");


    private JPanel resultContainer = new JPanel(new GridLayout(2, 1, 5, 5));
    private JLabel scoreDisplay = new JLabel("Your BMI: --", SwingConstants.LEFT);
    private JLabel categoryDisplay = new JLabel("Category: --", SwingConstants.LEFT);

    public BMIGui() {// Window එක සාදා ගැනීම
        setTitle("University of Ruhuna - BMI Calculator");
        setSize(480, 580);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));


        JPanel topContainer = new JPanel();
        topContainer.setLayout(new BoxLayout(topContainer, BoxLayout.Y_AXIS));


        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        topContainer.add(headerLabel);


        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        ButtonGroup group = new ButtonGroup();
        group.add(metricRadio);
        group.add(imperialRadio);
        radioPanel.add(metricRadio);
        radioPanel.add(imperialRadio);
        topContainer.add(radioPanel);

        add(topContainer, BorderLayout.NORTH);


        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));


        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(heightLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        formPanel.add(heightField, gbc);
        gbc.gridx = 2; gbc.gridy = 0;
        formPanel.add(heightHint, gbc);


        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(weightLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        formPanel.add(weightField, gbc);
        gbc.gridx = 2; gbc.gridy = 1;
        formPanel.add(weightHint, gbc);


        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
        gbc.insets = new Insets(15, 5, 10, 5);
        JPanel btnWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        btnWrapper.add(calculateButton);
        formPanel.add(btnWrapper, gbc);

        centerPanel.add(formPanel);
        centerPanel.add(Box.createVerticalStrut(15));


        TitledBorder resultBorder = BorderFactory.createTitledBorder("YOUR RESULT");
        resultBorder.setTitleFont(new Font("Arial", Font.BOLD, 12));
        resultContainer.setBorder(resultBorder);

        scoreDisplay.setFont(new Font("Arial", Font.BOLD, 13));
        categoryDisplay.setFont(new Font("Arial", Font.BOLD, 13));
        resultContainer.add(scoreDisplay);
        resultContainer.add(categoryDisplay);


        resultContainer.setVisible(false);
        centerPanel.add(resultContainer);


        centerPanel.add(Box.createVerticalStrut(15));


        JTextArea referenceArea = new JTextArea(
                " REFERENCE INFORMATION\n\n" +
                        " BMI Values Chart:\n" +
                        " • Underweight:  Less than 18.5\n" +
                        " • Normal:       Between 18.5 and 24.9\n" +
                        " • Overweight:   Between 25 and 29.9\n" +
                        " • Obese:        30 or greater\n\n" +
                        " Source: Department of Health and Human Services / NIH"
        );
        referenceArea.setEditable(false);
        referenceArea.setBackground(getBackground());
        referenceArea.setBorder(BorderFactory.createEtchedBorder());


        referenceArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

        centerPanel.add(referenceArea);

        add(centerPanel, BorderLayout.CENTER);

        // =====================================================================
        // EVENTS / ACTIONS HANDLING
        // =====================================================================

        ActionListener toggleListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resultContainer.setVisible(false);
                revalidate();
                repaint();
            }
        };
        metricRadio.addActionListener(toggleListener);
        imperialRadio.addActionListener(toggleListener);

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double height = Double.parseDouble(heightField.getText().trim());
                    double weight = Double.parseDouble(weightField.getText().trim());

                    if (height <= 0 || weight <= 0) {
                        throw new IllegalArgumentException("Values must be greater than zero.");
                    }

                    double bmi;
                    if (metricRadio.isSelected()) {
                        if (height > 3.0) {
                            height = height / 100.0;
                        }
                        bmi = weight / (height * height);
                    } else {
                        bmi = (weight / (height * height)) * 703;
                    }

                    bmi = Math.round(bmi * 100.0) / 100.0;

                    String category;
                    if (bmi < 18.5) {
                        category = "Underweight";
                    } else if (bmi <= 24.9) {
                        category = "Normal Weight";
                    } else if (bmi <= 29.9) {
                        category = "Overweight";
                    } else {
                        category = "Obese";
                    }

                    scoreDisplay.setText("Your BMI: [ " + bmi + " ]");
                    categoryDisplay.setText("Category: [ " + category + " ]");
                    resultContainer.setVisible(true);

                    revalidate();
                    repaint();

                } catch (Exception ex) {
                    resultContainer.setVisible(false);
                    revalidate();
                    repaint();
                    JOptionPane.showMessageDialog(null, "Please enter valid positive numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BMIGui().setVisible(true);
            }
        });
    }
}
